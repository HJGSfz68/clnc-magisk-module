#!/system/bin/sh
# 该脚本将在卸载期间执行，您可以编写自定义卸载规则

[ -x /data/防跳/clnc_magisk/webui/stop_httpd.sh ] && /system/bin/sh /data/防跳/clnc_magisk/webui/stop_httpd.sh >/dev/null 2>&1
rm -rf /data/防跳/clnc_magisk
