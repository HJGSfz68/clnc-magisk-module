# CLNC Magisk 模块

这是一个可直接安装的 Magisk 模块，安装后会在设备本机启动一个本地网页控制台。

## 本地网页

- 本机地址：`http://127.0.0.1:666`
- 页面顶部展示：`https://tool.lu/netcard/`
- 三个控制按钮：`开启`、`检测`、`关闭`
- 对应脚本：`开启.sh`、`检测.sh`、`关闭.sh`
- 执行结果会直接显示在页面中
- 页面下方提供网速检测按钮，点击后打开：`https://test.ustc.edu.cn/`

## 模块行为

- 安装时会把 `clnc_magisk` 复制到 `/data/防跳/clnc_magisk`
- 开机时 `service.sh` 会先启动本地网页服务，再根据 `config.ini` 决定是否自动启动 CLNC
- 网页服务使用模块自带 `busybox httpd`，监听 `127.0.0.1:666`
- `service.sh` 采用幂等启动和慢速看门狗策略，避免重复拉起与高频唤醒
- 看门狗默认每 5 分钟检查一次运行状态，只有在进程退出后才尝试重启，并带有 3 分钟冷却时间
- `clnc_magisk/control.sh` 统一封装 `start`、`stop`、`status`、`restart`，为网页按钮和开机脚本提供同一套状态检查与互斥控制
- 网页中的“检测”按钮保留原始 `CuteBi status` 详细输出，`control.sh status` 则提供简化健康状态给后台脚本使用
- 网页中的“开启”按钮会先判断当前是否已在运行；运行中直接输出详细检测结果，未运行时先启动再输出详细检测结果
- 为减轻 `tun + tproxy + CNS` 链路上的 UDP 分片问题，默认将 `tunMtu` 从 `1500` 下调到 `1400`
- 看门狗会低频读取一次原始状态输出；若连续两轮检测到 UDP 异常，会自动执行一次停止后重启的自恢复流程
- 自动自恢复重启时，会先临时关闭移动数据，再执行停止与启动，成功后恢复原有移动数据状态，尽量减少流量偷跑窗口

## 目录说明

- `clnc_magisk/webui/index.html`：本地网页页面
- `clnc_magisk/webui/start_httpd.sh`：启动本地网页服务
- `clnc_magisk/webui/stop_httpd.sh`：停止本地网页服务
- `clnc_magisk/webui/cgi-bin/run.sh`：网页按钮执行入口

## 使用方式

1. 在 Magisk 中安装模块 zip。
2. 重启设备。
3. 使用浏览器访问 `http://127.0.0.1:666`。
4. 在页面中点击按钮执行对应脚本。
