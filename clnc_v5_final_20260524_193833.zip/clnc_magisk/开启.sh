#!/system/bin/sh

BASE_DIR="${0%/*}"

if /system/bin/sh "$BASE_DIR/control.sh" status >/dev/null 2>&1; then
  /system/bin/sh "$BASE_DIR/control.sh" status-raw
  exit 0
fi

/system/bin/sh "$BASE_DIR/control.sh" start
start_exit_code=$?

printf '\n'
/system/bin/sh "$BASE_DIR/control.sh" status-raw
exit "$start_exit_code"
