#!/system/bin/sh

printf 'Content-Type: text/plain; charset=UTF-8\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

DEFAULT_MODULE_DIR='/data/防跳/clnc_magisk'
SCRIPT_DIR="${0%/*}"
WEBUI_DIR="${SCRIPT_DIR%/*}"
RELATIVE_MODULE_DIR="${WEBUI_DIR%/*}"

if [ -d "$DEFAULT_MODULE_DIR" ]; then
  MODULE_DIR="$DEFAULT_MODULE_DIR"
else
  MODULE_DIR="$RELATIVE_MODULE_DIR"
fi

case "$QUERY_STRING" in
  action=start) action="start" ;;
  action=status) action="status" ;;
  action=stop) action="stop" ;;
  *)
    printf '无效操作：%s\n' "$QUERY_STRING"
    exit 0
  ;;
esac

case "$action" in
  start) target_script="$MODULE_DIR/开启.sh" ; label='开启' ;;
  status) target_script="$MODULE_DIR/检测.sh" ; label='检测' ;;
  stop) target_script="$MODULE_DIR/关闭.sh" ; label='关闭' ;;
esac

chmod 755 "$MODULE_DIR/Core/busybox" "$MODULE_DIR/Core/CuteBi" "$MODULE_DIR/Core/MLBox" "$MODULE_DIR/Core/clnc" "$MODULE_DIR/control.sh" "$target_script" 2>/dev/null

printf '操作：%s\n' "$label"
printf '时间：%s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
printf '路径：%s\n' "$target_script"
printf '----------------------------------------\n'

cd "$MODULE_DIR" || {
  printf '模块目录不可访问\n'
  printf '当前模块目录：%s\n' "$MODULE_DIR"
  exit 0
}

/system/bin/sh "$target_script" 2>&1
exit_code=$?

printf '\n----------------------------------------\n'
printf '退出码：%s\n' "$exit_code"
