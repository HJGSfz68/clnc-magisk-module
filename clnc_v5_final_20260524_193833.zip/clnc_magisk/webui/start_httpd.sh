#!/system/bin/sh

BASE_DIR="${0%/*}"
MODULE_DIR="${BASE_DIR%/*}"
BUSYBOX_BIN="$MODULE_DIR/Core/busybox"
PID_FILE="$BASE_DIR/httpd.pid"
PORT="666"
HOST="127.0.0.1"

[ -x "$BUSYBOX_BIN" ] || chmod 755 "$BUSYBOX_BIN" 2>/dev/null
[ -x "$BASE_DIR/cgi-bin/run.sh" ] || chmod 755 "$BASE_DIR/cgi-bin/run.sh" 2>/dev/null

if [ -f "$PID_FILE" ]; then
  old_pid="$(cat "$PID_FILE" 2>/dev/null)"
  if [ -n "$old_pid" ] && [ -d "/proc/$old_pid" ]; then
    exit 0
  fi
fi

cd "$BASE_DIR" || exit 1
"$BUSYBOX_BIN" httpd -f -p "$HOST:$PORT" -h "$BASE_DIR" >/dev/null 2>&1 &
echo $! > "$PID_FILE"
chmod 644 "$PID_FILE" 2>/dev/null
