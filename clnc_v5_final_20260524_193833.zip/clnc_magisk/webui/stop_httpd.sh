#!/system/bin/sh

BASE_DIR="${0%/*}"
PID_FILE="$BASE_DIR/httpd.pid"

if [ -f "$PID_FILE" ]; then
  pid="$(cat "$PID_FILE" 2>/dev/null)"
  if [ -n "$pid" ] && [ -d "/proc/$pid" ]; then
    kill "$pid" >/dev/null 2>&1
  fi
  rm -f "$PID_FILE"
fi
