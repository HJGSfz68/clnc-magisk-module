#!/system/bin/sh

/system/bin/sh "${0%/*}/control.sh" status-raw
