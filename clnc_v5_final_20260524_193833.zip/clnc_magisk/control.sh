#!/system/bin/sh

BASE_DIR="${0%/*}"
CORE_DIR="$BASE_DIR/Core"
LOG_DIR="$BASE_DIR/logs"
STATUS_LOG="$LOG_DIR/control.log"
LOCK_DIR="$BASE_DIR/.control_lock"
PID_FILE="$CORE_DIR/clnc.pid"
LOCK_PID_FILE="$LOCK_DIR/pid"

log_msg() {
  mkdir -p "$LOG_DIR" 2>/dev/null
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$1" >> "$STATUS_LOG"
}

prepare() {
  mkdir -p "$LOG_DIR" 2>/dev/null
  chmod 755 "$CORE_DIR/busybox" "$CORE_DIR/CuteBi" "$CORE_DIR/MLBox" "$CORE_DIR/clnc" 2>/dev/null
  cd "$BASE_DIR" || exit 1
}

pid_from_file() {
  [ -f "$PID_FILE" ] || return 1
  grep -o '^[0-9]\+' "$PID_FILE" 2>/dev/null
}

proc_running() {
  local pid
  pid="$(pid_from_file)"
  [ -n "$pid" ] || return 1
  [ -d "/proc/$pid" ] || return 1
  return 0
}

lock_owner_running() {
  [ -f "$LOCK_PID_FILE" ] || return 1

  local pid
  pid="$(cat "$LOCK_PID_FILE" 2>/dev/null)"
  [ -n "$pid" ] || return 1
  [ -d "/proc/$pid" ] || return 1
  return 0
}

tun_ready() {
  "$CORE_DIR/busybox" ifconfig tunDev >/dev/null 2>&1
}

status_raw() {
  /system/bin/sh "$CORE_DIR/CuteBi" status
}

is_healthy() {
  if status_raw >/dev/null 2>&1; then
    return 0
  fi

  if proc_running && tun_ready; then
    return 0
  fi

  return 1
}

wait_healthy() {
  local delay=1
  local tries=15

  while [ "$tries" -gt 0 ]; do
    if is_healthy; then
      return 0
    fi

    sleep "$delay"
    tries=$((tries - 1))
    [ "$delay" -lt 3 ] && delay=$((delay + 1))
  done

  return 1
}

run_with_lock() {
  local action="$1"
  shift
  local wait_count=0

  while [ "$wait_count" -lt 10 ]; do
    if mkdir "$LOCK_DIR" 2>/dev/null; then
      echo $$ > "$LOCK_PID_FILE"
      trap 'rm -f "$LOCK_PID_FILE" >/dev/null 2>&1; rmdir "$LOCK_DIR" >/dev/null 2>&1' EXIT INT TERM
      "$action" "$@"
      local exit_code=$?
      rm -f "$LOCK_PID_FILE" >/dev/null 2>&1
      rmdir "$LOCK_DIR" >/dev/null 2>&1
      trap - EXIT INT TERM
      return "$exit_code"
    fi

    if ! lock_owner_running; then
      rm -f "$LOCK_PID_FILE" >/dev/null 2>&1
      rmdir "$LOCK_DIR" >/dev/null 2>&1
      continue
    fi

    sleep 1
    wait_count=$((wait_count + 1))
  done

  log_msg "skip action because another control command is running"
  return 2
}

do_start() {
  if is_healthy; then
    log_msg "start skipped because service is already healthy"
    return 0
  fi

  /system/bin/sh "$CORE_DIR/CuteBi" start >> "$STATUS_LOG" 2>&1

  if wait_healthy; then
    log_msg "service started successfully"
    return 0
  fi

  log_msg "service start ended without healthy state"
  return 1
}

do_stop() {
  if ! proc_running && ! status_raw >/dev/null 2>&1; then
    log_msg "stop skipped because service is already stopped"
    return 0
  fi

  /system/bin/sh "$CORE_DIR/CuteBi" stop >> "$STATUS_LOG" 2>&1
  sleep 2

  if proc_running; then
    log_msg "service stop left process alive"
    return 1
  fi

  log_msg "service stopped"
  return 0
}

do_status() {
  if is_healthy; then
    printf 'running\n'
    return 0
  fi

  if proc_running; then
    printf 'degraded\n'
    return 1
  fi

  printf 'stopped\n'
  return 1
}

do_restart() {
  do_stop
  do_start
}

prepare

[ -n "$1" ] || set -- status

case "$1" in
  start)
    run_with_lock do_start
  ;;
  stop)
    run_with_lock do_stop
  ;;
  restart)
    run_with_lock do_restart
  ;;
  status)
    do_status
  ;;
  status-raw)
    status_raw
  ;;
  *)
    printf 'usage: %s {start|stop|restart|status|status-raw}\n' "$0"
    exit 1
  ;;
esac
