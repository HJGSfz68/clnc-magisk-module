#!/system/bin/sh

MODDIR=${0%/*}
DATA_ROOT="/data/防跳"
DATA_DIR="$DATA_ROOT/clnc_magisk"
CORE_DIR="$DATA_DIR/Core"
WEBUI_DIR="$DATA_DIR/webui"
CONTROL_SCRIPT="$DATA_DIR/control.sh"
LOG_DIR="$DATA_DIR/logs"
LOCK_DIR="$DATA_DIR/.service_lock"
WATCHDOG_PID_FILE="$DATA_DIR/.watchdog.pid"
UDP_FAIL_FILE="$DATA_DIR/.udp_fail_count"
MOBILE_DATA_FLAG_FILE="$DATA_DIR/.mobile_data_restore"
STATUS_LOG="$LOG_DIR/service.log"

log_msg() {
  mkdir -p "$LOG_DIR" 2>/dev/null
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$1" >> "$STATUS_LOG"
}

ensure_data_dir() {
  mkdir -p "$DATA_ROOT" "$LOG_DIR" 2>/dev/null
  [ -d "$DATA_DIR" ] || cp -af "$MODDIR/clnc_magisk" "$DATA_DIR"
  chmod 755 "$CORE_DIR/busybox" "$CORE_DIR/CuteBi" "$CORE_DIR/MLBox" "$CORE_DIR/clnc" 2>/dev/null
  chmod 755 "$CONTROL_SCRIPT" "$WEBUI_DIR/start_httpd.sh" "$WEBUI_DIR/stop_httpd.sh" "$WEBUI_DIR/cgi-bin/run.sh" 2>/dev/null
}

start_webui() {
  local pid_file="$WEBUI_DIR/httpd.pid"

  [ -d "$WEBUI_DIR" ] || return
  [ -f "$CORE_DIR/busybox" ] || return

  if [ -f "$pid_file" ]; then
    local old_pid
    old_pid="$(cat "$pid_file" 2>/dev/null)"
    if [ -n "$old_pid" ] && [ -d "/proc/$old_pid" ]; then
      return
    fi
  fi

  /system/bin/sh "$WEBUI_DIR/start_httpd.sh" >/dev/null 2>&1 &
  sleep 1
  [ -f "$pid_file" ] && chmod 644 "$pid_file" 2>/dev/null
}

is_running() {
  [ -f "$CONTROL_SCRIPT" ] || return 1
  /system/bin/sh "$CONTROL_SCRIPT" status >/dev/null 2>&1
}

wait_for_network() {
  local delay=3
  local waited=0
  local max_wait=90

  while [ "$waited" -lt "$max_wait" ]; do
    if ! "$CORE_DIR/MLBox" -timeout=1 -dns="-domain=ip.sb -qtype=A" 2>/dev/null | grep -q 'network is unreachable'; then
      return 0
    fi

    sleep "$delay"
    waited=$((waited + delay))
    [ "$delay" -lt 15 ] && delay=$((delay + 2))
  done

  return 1
}

start_clnc() {
  if is_running; then
    log_msg "CLNC already running"
    return 0
  fi

  /system/bin/sh "$CONTROL_SCRIPT" start >> "$STATUS_LOG" 2>&1

  if is_running; then
    log_msg "CLNC started"
    return 0
  fi

  log_msg "CLNC start failed"
  return 1
}

stop_clnc() {
  /system/bin/sh "$CONTROL_SCRIPT" stop >> "$STATUS_LOG" 2>&1
}

check_udp_health() {
  local status_output

  [ -f "$CONTROL_SCRIPT" ] || return 1
  status_output="$(/system/bin/sh "$CONTROL_SCRIPT" status-raw 2>/dev/null)"
  [ -n "$status_output" ] || return 1

  printf '%s\n' "$status_output" | grep -q 'UDP联网成功'
}

get_udp_fail_count() {
  [ -f "$UDP_FAIL_FILE" ] || {
    printf '0\n'
    return 0
  }

  grep -o '^[0-9]\+' "$UDP_FAIL_FILE" 2>/dev/null || printf '0\n'
}

set_udp_fail_count() {
  printf '%s\n' "$1" > "$UDP_FAIL_FILE"
}

mobile_data_is_enabled() {
  [ "$(settings get global mobile_data 2>/dev/null)" = "1" ]
}

disable_mobile_data_temporarily() {
  rm -f "$MOBILE_DATA_FLAG_FILE" >/dev/null 2>&1

  if mobile_data_is_enabled; then
    printf '1\n' > "$MOBILE_DATA_FLAG_FILE"
    svc data disable >/dev/null 2>&1
    log_msg "Temporarily disabled mobile data before CLNC restart"
    sleep 2
  fi
}

restore_mobile_data_if_needed() {
  [ -f "$MOBILE_DATA_FLAG_FILE" ] || return 0

  svc data enable >/dev/null 2>&1
  rm -f "$MOBILE_DATA_FLAG_FILE" >/dev/null 2>&1
  log_msg "Restored mobile data after CLNC restart"
}

restart_clnc_safely() {
  disable_mobile_data_temporarily
  stop_clnc
  sleep 3
  set_udp_fail_count 0

  if wait_for_network; then
    start_clnc
    restore_mobile_data_if_needed
    return 0
  fi

  restore_mobile_data_if_needed
  return 1
}

start_watchdog() {
  if [ -f "$WATCHDOG_PID_FILE" ]; then
    local watchdog_pid
    watchdog_pid="$(cat "$WATCHDOG_PID_FILE" 2>/dev/null)"
    if [ -n "$watchdog_pid" ] && [ -d "/proc/$watchdog_pid" ]; then
      return
    fi
  fi

  (
    umask 022
    echo $$ > "$WATCHDOG_PID_FILE"
    trap 'rm -f "$WATCHDOG_PID_FILE"' EXIT

    local cooldown_until=0
    local restart_delay=300
    local udp_fail_threshold=2

    while :; do
      sleep "$restart_delay"

      grep -q "^autoStart='1'" "$DATA_DIR/config.ini" 2>/dev/null || continue

      if is_running; then
        if check_udp_health; then
          set_udp_fail_count 0
          continue
        fi

        local udp_fail_count
        udp_fail_count="$(get_udp_fail_count)"
        udp_fail_count=$((udp_fail_count + 1))
        set_udp_fail_count "$udp_fail_count"

        log_msg "Watchdog detected UDP unhealthy state ($udp_fail_count/$udp_fail_threshold)"

        if [ "$udp_fail_count" -lt "$udp_fail_threshold" ]; then
          continue
        fi

        local now
        now="$(date +%s 2>/dev/null)"
        [ -n "$now" ] || now=0

        log_msg "Watchdog restarting CLNC because UDP health check failed repeatedly"
        restart_clnc_safely
        cooldown_until=$((now + 180))
        continue

      else
        set_udp_fail_count 0

        local now
        now="$(date +%s 2>/dev/null)"
        [ -n "$now" ] || now=0

        if [ "$now" -lt "$cooldown_until" ]; then
          continue
        fi

        if wait_for_network; then
          log_msg "Watchdog restarting CLNC"
          start_clnc
          cooldown_until=$((now + 180))
        else
          log_msg "Watchdog skipped restart because network is unavailable"
        fi
        continue
      fi

      local now
      now="$(date +%s 2>/dev/null)"
      [ -n "$now" ] || now=0

      if [ "$now" -lt "$cooldown_until" ]; then
        continue
      fi

      if wait_for_network; then
        restart_clnc_safely
        cooldown_until=$((now + 180))
      else
        log_msg "Watchdog skipped restart because network is unavailable after UDP recovery attempt"
      fi
    done
  ) >/dev/null 2>&1 &
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  exit 0
fi
trap 'rmdir "$LOCK_DIR" >/dev/null 2>&1' EXIT

ensure_data_dir
start_webui

grep -q "^autoStart='1'" "$DATA_DIR/config.ini" 2>/dev/null || exit 0

if wait_for_network; then
  start_clnc
else
  log_msg "Initial start continues without confirmed network"
  start_clnc
fi

start_watchdog
